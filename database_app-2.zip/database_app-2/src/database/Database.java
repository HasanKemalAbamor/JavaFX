package database;

import java.sql.*;
import java.util.ArrayList;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class Database {

    private String url;
    private String username;
    private String password;

    private static String currentTable;
    private static String currentOperation;
    private String rowData;

    public Connection connection;

    public Database() {
        try {

            url = "jdbc:mysql://localhost:3306/p6";
            username = "root";
            password = "pass";

            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(url, username, password);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public String getCurrentTable() {
        return currentTable;
    }

    public void setCurrentTable(String table) {
        currentTable = table;
    }

    public String getCurrentOperation() {
        return currentOperation;
    }

    public void setCurrentOperation(String operation) {
        currentOperation = operation;
    }

    public void setRowData(String data) {
        rowData = data;
    }

    public String getRowData() {
        return rowData;
    }

    public ArrayList<String> getTables() throws SQLException {

        ArrayList<String> tables = new ArrayList<String>();
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("show tables;");

        ResultSetMetaData metaData = resultSet.getMetaData();
        int columnCount = metaData.getColumnCount();

        System.out.println(columnCount);

        while (resultSet.next()) {
            for (int i = 1; i <= columnCount; i++) {
                String columnValue = resultSet.getString(i);
                tables.add(columnValue);
            }
        }
        return tables;
    }

    public void executeQuery(String query) throws SQLException {

        Statement statement = connection.createStatement();
        int resultSet = statement.executeUpdate(query);
        System.out.println(resultSet);

        // ResultSetMetaData metaData = resultSet.getMetaData();
        // int columnCount = metaData.getColumnCount();

        // while (resultSet.next()) {
        // for (int i = 1; i <= columnCount; i++) {
        // String columnValue = resultSet.getString(i);
        // System.out.println(columnValue);
        // }
        // System.out.println("");

    }

    public void fetchAndShow(TableView<ObservableList<String>> tableView, String query) {
        try {
            tableView.getItems().clear();
            tableView.getColumns().clear();

            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                final int colIndex = i;
                TableColumn<ObservableList<String>, String> col = new TableColumn<>(metaData.getColumnName(i));
                col.setCellValueFactory(cellData -> {
                    ObservableList<String> row = cellData.getValue();
                    return new SimpleStringProperty(row.get(colIndex - 1));
                });
                tableView.getColumns().add(col);
            }

            while (resultSet.next()) {
                ObservableList<String> rowData = FXCollections.observableArrayList();
                for (int i = 1; i <= columnCount; i++) {
                    rowData.add(resultSet.getString(i));
                }
                tableView.getItems().add(rowData);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
