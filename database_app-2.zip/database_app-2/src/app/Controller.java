package app;

import java.net.URL;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.annotation.processing.SupportedOptions;
import javax.xml.transform.Source;

import javafx.fxml.FXML;
import javafx.scene.paint.Color;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.TextField;
import javafx.scene.control.TableView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import database.Database;

public class Controller implements Initializable {

    private Database database;

    @FXML
    private Button addButton;

    @FXML
    private Button addUpdateButtton;

    @FXML
    private Button connectButton;

    @FXML
    private Label connectionStatus;

    @FXML
    private TextArea customResult;

    @FXML
    private Button deleteButton;

    @FXML
    private TextField depInput;

    @FXML
    private Button exeCustomButton;

    @FXML
    private TextField firstInput;

    @FXML
    private TextField lastInput;

    @FXML
    private TextField midInput;

    @FXML
    private TextField queryInput;

    @FXML
    private TableView<ObservableList<String>> resultTable;

    @FXML
    private TextField ssnInput;

    @FXML
    private ListView<?> tablesList;

    @FXML
    private Button updateButton;

    @FXML
    private Button showButton;

    @FXML
    private Label currentOperation;

    @FXML
    private TextArea customInput;

    @FXML
    private TextArea newData;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        tablesList.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                String selected = (String) tablesList.getSelectionModel().getSelectedItem();
                database.setCurrentTable(selected);
                database.fetchAndShow(resultTable, "select * from " + database.getCurrentTable() + ";");
            }
        });

        resultTable.setOnMouseClicked(event -> {
            ObservableList<String> rowData = resultTable.getSelectionModel().getSelectedItem();
            if (rowData != null) {
                database.setRowData(rowData.toString());
            }
        });
    }

    @FXML
    void connectToDatabase(MouseEvent event) throws SQLException {
        database = new Database();
        ArrayList<String> tables = database.getTables();

        ObservableList observableArrayList = FXCollections.observableArrayList(tables);
        tablesList.getItems().addAll(observableArrayList);

        connectionStatus.setTextFill(Color.DARKCYAN);
        connectionStatus.setText("Connected");

    }

    @FXML
    void addClicked(MouseEvent event) throws SQLException {
        currentOperation.setText("Add new data");
        database.setCurrentOperation("add");

    }

    @FXML
    void updateClicked(MouseEvent event) {
        currentOperation.setText("Update selected");
        database.setCurrentOperation("update");
    }

    public static void updateStudent(Connection connection, String[] newValues, String ssn) {
        String updateSql = "UPDATE Student " +
                "SET fName = ?, mi = ?, lName = ?, bDate = ?, street = ?, phone = ?, zipCode = ?, deptId = ? " +
                "WHERE ssn = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(updateSql)) {

            for (int i = 0; i < newValues.length; i++) {
                preparedStatement.setString(i + 1, newValues[i]);
            }

            preparedStatement.setString(newValues.length + 1, ssn);
            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println(rowsAffected);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void addUpdateClicked(MouseEvent event) throws SQLException {
        switch (database.getCurrentOperation()) {
            case "add":
                System.out.println("adding to current table");
                String n = newData.getText();
                String[] array1 = n.split(",");

                String[] valuesArray = array1;

                StringBuilder queryBuilder = new StringBuilder("INSERT INTO ")
                        .append(database.getCurrentTable())
                        .append(" VALUES (");

                for (int i = 0; i < valuesArray.length; i++) {
                    queryBuilder.append("'").append(valuesArray[i]).append("'");
                    if (i < valuesArray.length - 1) {
                        queryBuilder.append(", ");
                    }
                }

                queryBuilder.append(");");
                String query = queryBuilder.toString();

                database.executeQuery(query);
                database.fetchAndShow(resultTable, "select * from " +
                        database.getCurrentTable() + ";");

                break;

            case "update":

                System.out.println("updating element at current table");
                String raw = database.getRowData().substring(1, database.getRowData().length() - 1);
                String[] array = raw.split(", ");
                String ssn = array[0];
                String[] newValues = { "NewFirstName", "N", "NewLastName", "2000-01-01", "NewStreet", "12345678",
                        "54321", "COMP" };

                updateStudent(database.connection, newValues, ssn);

                break;

            default:
                System.out.println("no action selected");
                break;
        }
    }

    @FXML
    void deleteSelected(MouseEvent event) throws SQLException {
        String raw = database.getRowData().substring(1, database.getRowData().length() - 1);
        String[] array = raw.split(", ");

        switch (database.getCurrentTable()) {
            case "student":
                String query1 = "delete from " + database.getCurrentTable() + " where ssn=" +
                        array[0];

                database.executeQuery(query1);
                database.fetchAndShow(resultTable, "select * from " +
                        database.getCurrentTable() + ";");
                break;

            case "enrollment":
                String query2 = "delete from " + database.getCurrentTable() + " where ssn=" +
                        array[0] + " and courseId="
                        + array[1];

                database.executeQuery(query2);
                database.fetchAndShow(resultTable, "select * from " +
                        database.getCurrentTable() + ";");
                break;

            case "course":
                String query3 = "delete from " + database.getCurrentTable() + " where courseId=" +
                        array[0];

                database.executeQuery(query3);
                database.fetchAndShow(resultTable, "select * from " +
                        database.getCurrentTable() + ";");
                break;

            default:
                System.out.println("messed up");
                break;
        }
    }

    @FXML
    void customQueryClicked(MouseEvent event) throws SQLException {
        String q = customInput.getText();
        database.fetchAndShow(resultTable, q);

    }
}
